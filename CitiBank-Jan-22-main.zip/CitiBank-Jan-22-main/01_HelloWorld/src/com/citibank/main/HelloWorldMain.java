package com.citibank.main;

public class HelloWorldMain {
	int x;
	
	public static void main(String citibank[]) {
		System.out.println("Real Main");
	}
	public static void main(Integer i) {
		System.out.println("Hello World !!");
		System.out.print("Hello World !!");
		System.out.print("Hello World !!");
		System.out.print("Hello World !!" + 100);
	}
}
