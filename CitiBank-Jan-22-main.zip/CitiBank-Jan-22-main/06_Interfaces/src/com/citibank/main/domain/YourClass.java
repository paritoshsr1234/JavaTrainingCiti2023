package com.citibank.main.domain;

public class YourClass implements MyInterface {

	@Override
	public void show() {
		System.out.println("Show() of YourClass");
	}

}
