package com.citibank.main.domain;

public class MyClass implements MyInterface {

	@Override
	public void show() {
		System.out.println("Show() of MyClass!!");
	}

}
