package com.citibank.main.domain;

public interface MyInterface {
	public static final String message = "Interfaces are good for your application";
	void show();
}
