package com.citibank.main.domain;

public interface CalculationsInterface {
	public double doCalculations(double number1, double number2);
}
