package com.citibank.main;

public interface MyInterface {
	void greet();
}
