package com.citibank.main.domain;

public interface Greeter {
	public void greet();
}
